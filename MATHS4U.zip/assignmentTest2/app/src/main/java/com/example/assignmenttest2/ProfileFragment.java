package com.example.assignmenttest2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
private String profile;
private TextView profileName;
private Button settingsButton;
private TextView profileDescription;
    DataHolder data = new DataHolder();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);


        profile = data.getData();
        profileName = view.findViewById(R.id.profileName);
        settingsButton = view.findViewById(R.id.settingsButton);
        profileDescription = view.findViewById(R.id.ProfileStatus);

        if( profile == null || profile.isEmpty()){
            profile = "Enter New Profile Name";
            data.setData(profile);
            profileName.setText(profile);
        } else {
            profileName.setText(profile);

        }
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            openNameEdit();
            }
        });


        return view;

    }
public void openNameEdit(){

    Intent intent;
    intent = new Intent(getActivity(), EditName.class);
    startActivity(intent);


}

}
